import { QuizPipe } from './quiz.pipe';

describe('QuizPipe', () => {
  it('create an instance', () => {
    const pipe = new QuizPipe();
    expect(pipe).toBeTruthy();
  });
});
